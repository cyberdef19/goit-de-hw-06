import argparse
from pathlib import Path

from pyspark.sql import functions as F
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType
from configs import kafka_config

parser = argparse.ArgumentParser()
parser.add_argument(
    "--read-output-topic-only",
    action="store_true",
    help="Read and print the output Kafka topic without starting the input pipeline",
)
args = parser.parse_args()

topic_name = "oleksiy_building_sensors"
output_topic_name = "oleksiy_sensors_streaming_out"

def jaas_quote(value):
    return value.replace("\\", "\\\\").replace('"', '\\"')


sasl_jaas_config = (
    "org.apache.kafka.common.security.plain.PlainLoginModule required "
    f'username="{jaas_quote(kafka_config["username"])}" '
    f'password="{jaas_quote(kafka_config["password"])}";'
)

spark = (SparkSession.builder \
    .appName("Spark Streaming Example") \
    .master("local[*]") \
    .config(
        "spark.jars.packages",
        "org.apache.spark:spark-sql-kafka-0-10_2.13:4.2.0"
    )\
    .getOrCreate())  

df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers",  kafka_config["bootstrap_servers"]) \
    .option("kafka.security.protocol", kafka_config["security_protocol"]) \
    .option("kafka.sasl.mechanism", kafka_config["sasl_mechanism"]) \
    .option("kafka.sasl.jaas.config", sasl_jaas_config) \
    .option("subscribe", topic_name) \
    .option("startingOffsets", "earliest") \
    .load()

print(df.printSchema())

json_schema = StructType([
    StructField("uuide_sensor", StringType(), True),
    StructField("temperature", IntegerType(), True),
    StructField("humidity", IntegerType(), True),
    StructField("date_event", TimestampType(), True)
])



cleaned_df = df.selectExpr("CAST(key AS STRING) AS key_output", "CAST(value AS STRING) AS value_output", "*") \
            .drop("key", "value") \
            .withColumnRenamed("key_output", "key") \
            .withColumnRenamed("value_output", "value") \
            .withColumn("value_json", F.from_json(F.col("value"), json_schema)) \
            .withColumn("uuide_sensor", F.col("value_json.uuide_sensor")) \
            .withColumn("temperature", F.col("value_json.temperature")) \
            .withColumn("humidity", F.col("value_json.humidity")) \
            .withColumn("date_event", F.col("value_json.date_event")) \
            .drop("value_json")

windowed_df = cleaned_df.withWatermark("date_event", "1 minute") \
    .groupBy(
        F.window("date_event", "5 minute", "1 minute"),
        "uuide_sensor"
    ).agg(
        F.avg("temperature").alias("t_avg"),
        F.avg("humidity").alias("h_avg")
    )

schema_alert = StructType([
    StructField("id", IntegerType(), True),
    StructField("humidity_min", IntegerType(), True),
    StructField("humidity_max", IntegerType(), True),
    StructField("temperature_min", IntegerType(), True),
    StructField("temperature_max", IntegerType(), True),
    StructField("code", IntegerType(), True),
    StructField("message", StringType(), True)
])

df_alert = spark.read \
    .format("csv") \
    .option("header", "true") \
    .option("sep", ",") \
    .schema(schema_alert) \
    .csv(str(Path(__file__).with_name("alerts_conditions.csv")))

alert_condition = (
    (
        (F.col("humidity_min") != -999)
        & (F.col("humidity_max") != -999)
        & F.col("h_avg").between(
            F.col("humidity_min"), F.col("humidity_max")
        )
    )
    | (
        (F.col("temperature_min") != -999)
        & (F.col("temperature_max") != -999)
        & F.col("t_avg").between(
            F.col("temperature_min"), F.col("temperature_max")
        )
    )
)

alerts_df = (
    windowed_df
    .join(df_alert, alert_condition, "inner")
    .select(
        F.col("window.start").alias("window_start"),
        F.col("window.end").alias("window_end"),
        "uuide_sensor",
        "t_avg",
        "h_avg",
        F.col("id").alias("alert_id"),
        "code",
        "message",
    )
)

alerts_for_kafka = alerts_df.select(
    F.col("uuide_sensor").cast("string").alias("key"),
    F.to_json(
        F.struct(
            F.struct(
                F.col("window_start").alias("start"),
                F.col("window_end").alias("end"),
            ).alias("windows"),
            "t_avg",
            "h_avg",
            "code",
            "message",
            F.col("window_end").alias("timestamp"),
        )
    ).alias("value"),
)

console_df = (
    spark.readStream
    .format("kafka")
    .option("kafka.bootstrap.servers", kafka_config["bootstrap_servers"])
    .option("kafka.security.protocol", kafka_config["security_protocol"])
    .option("kafka.sasl.mechanism", kafka_config["sasl_mechanism"])
    .option("kafka.sasl.jaas.config", sasl_jaas_config)
    .option("subscribe", output_topic_name)
    .option("startingOffsets", "earliest")
    .load()
    .selectExpr(
        "CAST(key AS STRING) AS key",
        "CAST(value AS STRING) AS value",
        "topic",
        "partition",
        "offset",
        "timestamp",
    )
)

if args.read_output_topic_only:
    console_query = console_df.writeStream \
        .trigger(processingTime="10 seconds") \
        .outputMode("append") \
        .format("console") \
        .option("truncate", "false") \
        .option("checkpointLocation", str(Path(__file__).with_name("checkpoint_console"))) \
        .start()
    console_query.awaitTermination()
else:
    query = alerts_for_kafka.writeStream \
        .trigger(processingTime="10 seconds") \
        .format("kafka") \
        .option("kafka.bootstrap.servers", kafka_config["bootstrap_servers"]) \
        .option("kafka.security.protocol", kafka_config["security_protocol"]) \
        .option("kafka.sasl.mechanism", kafka_config["sasl_mechanism"]) \
        .option("kafka.sasl.jaas.config", sasl_jaas_config) \
        .option("topic", output_topic_name) \
        .option("checkpointLocation", str(Path(__file__).with_name("checkpoint"))) \
        .start()
    query.awaitTermination()

    
